document.getElementById("chatButton").onclick = function() {
    document.getElementById("chatBox").style.display = "block";
};

document.getElementById("closeChat").onclick = function() {
    document.getElementById("chatBox").style.display = "none";
};